﻿using Recipe_app_part_3;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_app_part_3
{ 
    
    /// Interaction logic for MainWindow.xaml
   
    public partial class MainWindow : Window
    {
        // ObservableCollection to store recipes
        private ObservableCollection<RecipeClass> recipes = new ObservableCollection<RecipeClass>();

     
        /// Constructor for MainWindow
        
        public MainWindow()
        {
            InitializeComponent();
        }

        
        /// Event handler for Add Recipe button click
       
        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Create a new RecipeClass object and populate it with data from the text boxes
            var recipe = new RecipeClass
            {
                RecipeName = RecipeNametext.Text,
                ingedients = ingredientstext.Text,
                foodGroup = FoodGrouptext.Text,
                calories = Caloriestext.Text,
                RecipeID = RecipeIDtext.Text,
                steps = Stepstext.Text,
            };

            // Add the recipe to the ObservableCollection
            recipes.Add(recipe);

            // Clear input fields after adding recipe
            Caloriestext.Clear();
            FoodGrouptext.Clear();
            Stepstext.Clear();
            RecipeNametext.Clear();
            RecipeIDtext.Clear();
            ingredientstext.Clear();
        }

    
        /// Event handler for Clear button click
     
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            // Clear all input fields
            Caloriestext.Clear();
            FoodGrouptext.Clear();
            Stepstext.Clear();
            RecipeNametext.Clear();
            RecipeIDtext.Clear();
            ingredientstext.Clear();
        }

 
        /// Event handler for View Recipes button click
    
        private void btnViewRecipres_Click(object sender, RoutedEventArgs e)
        {
            // Create and show a new ViewRecipeWindow, passing the recipes ObservableCollection
            ViewRecipeWindow viewRecipeWindow = new ViewRecipeWindow(recipes);
            viewRecipeWindow.Show();
        }
    }
}
