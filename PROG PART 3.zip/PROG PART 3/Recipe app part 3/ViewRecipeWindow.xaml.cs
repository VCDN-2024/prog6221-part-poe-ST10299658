﻿using System;
using System.Collections.ObjectModel;
using System.Windows;


namespace Recipe_app_part_3
{
   
    /// Interaction logic for SearchWindow.xaml
    
    public partial class ViewRecipeWindow : Window
    {
        private ObservableCollection<RecipeClass> recipes;
        public ViewRecipeWindow()
        {
            InitializeComponent();
        }

        // new constructor  that accepts the recipe collection 
        public ViewRecipeWindow(ObservableCollection<RecipeClass> recipeCollection) : this()
        {
            // Initializing the recipe collection
            recipes = recipeCollection;

            // Displaingy the recipes
            txbResult.Text = string.Join("\n\n", recipes.Select(r => r.ToString()));
        }



        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchText = txbSearch.Text.ToLower();

            // finding the recipe with the matching id
            var searchRecipe = recipes.FirstOrDefault(r => r.RecipeID.ToLower() == searchText || r.RecipeName.ToLower() == searchText || r.foodGroup.ToLower() == searchText || r.calories.ToLower() == searchText);

            if (searchRecipe != null)
            {
                //displaying recipe details 
                txbResult.Text = searchRecipe.ToString();
            }

            else
            {
                // clearing the details in the text block if on match is found
                txbResult.Text = "No recipe with the matching ID was found";

            }
            txbSearch.Clear();




        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            // display all the books 
            txbResult.Text = string.Join("\n\n", recipes.Select(r => r.ToString()));

        }
    }
}
