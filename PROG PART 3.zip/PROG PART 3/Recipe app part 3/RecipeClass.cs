﻿using System;
using System.Collections.Generic;
namespace Recipe_app_part_3
{
    /// Represents a recipe with its properties.

    public class RecipeClass
    {
        // Properties of the RecipeClass
        public string RecipeID { get; set; }       // Unique identifier for the recipe
        public string RecipeName { get; set; }     // Name of the recipe
        public string ingedients { get; set; }     // Ingredients of the recipe (typo in property name)
        public string foodGroup { get; set; }      // Food group to which the recipe belongs
        public string calories { get; set; }       // Number of calories in the recipe
        public string steps { get; set; }          // Preparation steps for the recipe

        
        /// Overrides the ToString() method to provide a formatted string representation of the RecipeClass object.
    
        /// <returns>A string representation of the RecipeClass object.</returns>
        public override string ToString()
        {
            return $"RecipeID: {RecipeID}\nRecipeName: {RecipeName}\nIngredients: {ingedients}\nFoodGroup: {foodGroup}\nCalories: {calories}\nSteps: {steps}\n";
        }
    }
}
